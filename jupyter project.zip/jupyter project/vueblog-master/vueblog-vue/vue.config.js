module.exports = {
  publicPath: '/'
}