package com.example.dormitory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DormitoryApplicationTests {

    @Test
    void contextLoads() {
    }

}
